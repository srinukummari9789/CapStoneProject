package com.example.ExceltoDB.ExceltoDbSpringBatch.model;

import org.springframework.batch.core.JobExecution;

public interface JobCompletionNotificationListener {
	public void afterJob(JobExecution jobExecution);

}
