package com.example.ExceltoDB.ExceltoDbSpringBatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceltoDbSpringBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
