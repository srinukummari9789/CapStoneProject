package com.example.readingExceltoDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadingExceltoDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
