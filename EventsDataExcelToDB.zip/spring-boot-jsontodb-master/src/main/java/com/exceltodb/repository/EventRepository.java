package com.exceltodb.repository;

import org.springframework.data.repository.CrudRepository;

import com.exceltodb.domain.Events;

public interface EventRepository extends CrudRepository<Events, Integer> {



}
