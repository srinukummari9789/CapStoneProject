package com.exceltodb.service;

import com.exceltodb.domain.Events;
import com.exceltodb.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventService {
	
	@Autowired
    private EventRepository eventRepository;
	
   
    public Iterable<Events> list() {
        return eventRepository.findAll();
    }

    public Events save(Events event) {
        return eventRepository.save(event);
    }

    public void save(List<Events> events) {
        eventRepository.save(events);
    }
}
