package com.exceltodb.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.exceltodb.domain.Events;
import com.exceltodb.service.EventService;

@RestController
public class EventController {
	
	@Autowired
    private EventService eventService;

   
    @PostMapping("/uploadEvents")
    public List<Events> mapEventsDataExceltoDB(@RequestParam("file") MultipartFile reapExcelDataFile) throws IOException {

       List<Events> tempEventsList = new ArrayList<Events>();
        XSSFWorkbook workbook = new XSSFWorkbook(reapExcelDataFile.getInputStream());
        XSSFSheet worksheet = workbook.getSheetAt(0);

        Events event = null;
        for(int i=1;i<worksheet.getPhysicalNumberOfRows() ;i++) {
            Events tempEvents = new Events();

            XSSFRow row = worksheet.getRow(i);

            tempEvents.setId((int) row.getCell(0).getNumericCellValue());
            tempEvents.setEvent_id(row.getCell(1).getStringCellValue());
            tempEvents.setBase_location(row.getCell(2).getStringCellValue());
            tempEvents.setBeneficiary_name(row.getCell(3).getStringCellValue());
            tempEvents.setCouncil_name(row.getCell(4).getStringCellValue());
            tempEvents.setEvent_name(row.getCell(5).getStringCellValue());
            tempEvents.setEvent_description(row.getCell(6).getStringCellValue());
            tempEvents.setEvent_date(row.getCell(7).getDateCellValue());
            tempEvents.setEmployee_id(row.getCell(8).getStringCellValue());
            tempEvents.setEmployee_name(row.getCell(9).getStringCellValue());
            tempEvents.setVolunteer_hours((int) row.getCell(10).getNumericCellValue());
            tempEvents.setTravel_hours((int) row.getCell(11).getNumericCellValue());
            tempEvents.setLives_impacted((int) row.getCell(12).getNumericCellValue());
            tempEvents.setBusiness_unit(row.getCell(13).getStringCellValue());
            tempEvents.setEvent_status(row.getCell(14).getStringCellValue());
            tempEvents.setIiep_category(row.getCell(15).getStringCellValue()); 
            event = eventService.save(tempEvents);
            System.out.println(event.toString());
            tempEventsList.add(event);
        }
		return tempEventsList;
    }

}
