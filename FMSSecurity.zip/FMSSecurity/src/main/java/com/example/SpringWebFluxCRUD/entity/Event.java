package com.example.SpringWebFluxCRUD.entity;


import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table("event")
//@Document 
@Data 
@AllArgsConstructor
@NoArgsConstructor
public class Event {	
	
	@Id
	private int id;
	private int event_Id;
	private String event_Name;
	private Date event_Date;
	private String business_Unit;
	private String venue;
	private int total_Vollunteers;
	private int total_Participants;
	private int lives_Impacted;
	private int vallunteer_Hours;
	private int travel_Hours;
	
	public Event() {
		super();
	}
	
	public Event(int id, int event_Id, String event_Name, Date event_Date, String business_Unit, String venue,
			int total_Vollunteers, int total_Participants, int lives_Impacted, int vallunteer_Hours, int travel_Hours) {
		super();
		this.id = id;
		this.event_Id = event_Id;
		this.event_Name = event_Name;
		this.event_Date = event_Date;
		this.business_Unit = business_Unit;
		this.venue = venue;
		this.total_Vollunteers = total_Vollunteers;
		this.total_Participants = total_Participants;
		this.lives_Impacted = lives_Impacted;
		this.vallunteer_Hours = vallunteer_Hours;
		this.travel_Hours = travel_Hours;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEvent_Id() {
		return event_Id;
	}
	public void setEvent_Id(int event_Id) {
		this.event_Id = event_Id;
	}
	public String getEvent_Name() {
		return event_Name;
	}
	public void setEvent_Name(String event_Name) {
		this.event_Name = event_Name;
	}
	public Date getEvent_Date() {
		return event_Date;
	}
	public void setEvent_Date(Date event_Date) {
		this.event_Date = event_Date;
	}
	public String getBusiness_Unit() {
		return business_Unit;
	}
	public void setBusiness_Unit(String business_Unit) {
		this.business_Unit = business_Unit;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	public int getTotal_Vollunteers() {
		return total_Vollunteers;
	}
	public void setTotal_Vollunteers(int total_Vollunteers) {
		this.total_Vollunteers = total_Vollunteers;
	}
	public int getTotal_Participants() {
		return total_Participants;
	}
	public void setTotal_Participants(int total_Participants) {
		this.total_Participants = total_Participants;
	}
	public int getLives_Impacted() {
		return lives_Impacted;
	}
	public void setLives_Impacted(int lives_Impacted) {
		this.lives_Impacted = lives_Impacted;
	}
	public int getVallunteer_Hours() {
		return vallunteer_Hours;
	}
	public void setVallunteer_Hours(int vallunteer_Hours) {
		this.vallunteer_Hours = vallunteer_Hours;
	}
	public int getTravel_Hours() {
		return travel_Hours;
	}
	public void setTravel_Hours(int travel_Hours) {
		this.travel_Hours = travel_Hours;
	}
	
	
}
