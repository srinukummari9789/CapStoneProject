package com.example.SpringWebFluxCRUD.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringWebFluxCRUD.entity.Dashboard;
import com.example.SpringWebFluxCRUD.entity.Event;
import com.example.SpringWebFluxCRUD.entity.User;
import com.example.SpringWebFluxCRUD.repository.UserRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class UserController {
	
	@Autowired
	private UserRepository userRepository;
	/*
	@GetMapping("/users")
	public Flux<Event> getAll(){
		 System.out.println("************");
		return userRepository.findAll();
	}
	
	
	/*
	 * @RequestMapping(value = "/addUser", method = RequestMethod.POST, consumes =
	 * MediaType.APPLICATION_JSON_UTF8_VALUE)
	 * 
	 * public Mono<Event> addData(@RequestBody Event event){ return
	 * userRepository.save(event); }
	 */
	  @ResponseStatus(HttpStatus.CREATED)
	  @PostMapping(v"/add")
		public Mono<Event> addData(@RequestBody Event user) {
				return userRepository.save(user);
		}
	 
	
	/*
	 * @PostMapping("/addUser") public Mono<Event> addCricketer(@RequestBody Event
	 * cricketer) { System.out.println(cricketer.getEventName()); return
	 * userRepository.save(cricketer); }
	 */
	
	@DeleteMapping("/delete/{id}")
	public Mono<Void> deleteData(@PathVariable("id") int id){
		return userRepository.deleteById(id);
	}
	
	/*
	 * @PutMapping("/update/{id}") public Mono<User> updateDate(@PathVariable("id")
	 * int id, @RequestBody Event event){
	 * 
	 * return userRepository.findById(id).flatMap(currentUser -> {
	 * currentUser.setName(user.getName()); currentUser.setEmail(user.getEmail());
	 * return userRepository.save(currentUser); });
	 * 
	 * }
	 */
	/*
	@GetMapping(value = "/getDashboardData")
	//@PreAuthorize("hasRole('PMO') or hasRole('ADMIN')")
	public Flux<Dashboard> dashboardData() {
		Dashboard dashBoard = new Dashboard();
		// int count=eventRepo.getAllEvents();
		Mono<Long> m1 = userRepository.findAll().count();
		//m1.count().subscribe(s -> dashBoard.setCount(Integer.parseInt(s.toString())));
		m1.subscribe(s -> dashBoard.setCount(Integer.parseInt(s.toString())));
		// dashBoard.setCount(15);
		Mono<Integer> m2 = userRepository.findAll().map(x -> x.getTotalVollunteers()).reduce(0, (a, b) -> a + b).log();

		m2.subscribe(s -> dashBoard.setTotalVolunteers(Integer.parseInt(s.toString())));

		Mono<Integer> m3 = userRepository.findAll().map(x -> x.getLivesImpacted()).reduce(0, (a, b) -> a + b).log();
		m3.subscribe(s -> dashBoard.setLivesImpacted(Integer.parseInt(s.toString())));
		Mono<Integer> m4 = userRepository.findAll().map(x -> x.getTotalParticipants()).reduce(0, (a, b) -> a + b);
		m4.subscribe(s -> dashBoard.setTotalParticipants(Integer.parseInt(s.toString())));

		System.out.println(dashBoard.getLivesImpacted()+"  "+dashBoard.getCount());

		List<Dashboard> list = new ArrayList<>();
		list.add(dashBoard);
		//return Flux.fromIterable(list);
		//emailService.sendMail("sumansatpathy5@gmail.com", "FMS Report", "Hi,PFA");
		return Flux.fromIterable(list);
		// return eventRepo.getAllEvents().map(x->
		// x.getTotalVollunteers()).reduce(0, (a, b) -> a + b);

	}*/
	
	

}




