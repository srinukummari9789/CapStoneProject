package com.example.SpringWebFluxCRUD.entity;

import reactor.core.publisher.Mono;

public class Dashboard {
private int count;
private int totalVolunteers;
private int livesImpacted;
private int totalParticipants;
public int getCount() {
	return count;
}
public void setCount(int i) {
	this.count = i;
}
public int getTotalVolunteers() {
	return totalVolunteers;
}
public void setTotalVolunteers(int totalVolunteers) {
	this.totalVolunteers = totalVolunteers;
}
public int getLivesImpacted() {
	return livesImpacted;
}
public void setLivesImpacted(int livesImpacted) {
	this.livesImpacted = livesImpacted;
}
public int getTotalParticipants() {
	return totalParticipants;
}
public void setTotalParticipants(int totalParticipants) {
	this.totalParticipants = totalParticipants;
}
@Override
public String toString() {
	return "Dashboard [count=" + count + ", totalVolunteers=" + totalVolunteers + ", livesImpacted=" + livesImpacted
			+ ", totalParticipants=" + totalParticipants + "]";
}




}
